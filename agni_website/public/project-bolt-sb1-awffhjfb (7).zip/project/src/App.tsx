import React, { useEffect, useRef, useState } from 'react';
import { Shield, Zap, Cpu, Puzzle, Leaf, TrendingUp, Store, Smartphone, Satellite, Dna } from 'lucide-react';

const agniFeatures = [
  {
    icon: Shield,
    title: "Self-Defending Unit",
    description: "World's first smart farm device that defends against 97% of threats—no drones, no chemicals, no compromise.",
  },
  {
    icon: Zap,
    title: "25+ Gadget Fusion",
    description: "Combines 25+ patent-worthy gadgets into one modular unit, adaptable to every crop, region & season.",
  },
  {
    icon: Cpu,
    title: "Swarm-Powered AI Defense",
    description: "AI Swarm predicts, protects, and personalizes defenses for each farm—zero guesswork or monitoring needed.",
  },
  {
    icon: Puzzle,
    title: "Plug & Play Farming",
    description: "LEGO-style design lets farmers snap upgrades, switch features, and scale without any tech knowledge.",
  },
  {
    icon: Leaf,
    title: "Eco-Warrior Core",
    description: "Operates on sun & wind. Zero emissions. Saves soil, water & bees while replacing ₹50K+ pesticides.",
  },
  {
    icon: TrendingUp,
    title: "Upgradeable & Always-On",
    description: "Start small, expand anytime. AGNI grows with your budget—backed by 24/7 support & auto-defend system.",
  },
  {
    icon: Store,
    title: "Farmer-to-Founder Model",
    description: "Every AGNI buyer becomes a rural entrepreneur with lifetime passive income from their own micro-grid.",
  },
  {
    icon: Smartphone,
    title: "AGNI Mart + Appstore",
    description: "Farmers shop, sell, upgrade, and automate on a single superapp—their own Amazon, just smarter.",
  },
  {
    icon: Satellite,
    title: "ISRO-Tuned Smart Alerts",
    description: "Live sync with satellite data to alert, repel & protect—all before pests even touch your farm.",
  },
  {
    icon: Dna,
    title: "AGNI DNA™ Personalization",
    description: "Every unit adapts to local crops, weather & pests—learning your farm like a fingerprint, improving over time.",
  },
];

const taglines = [
  '"One Tap. Total Control." AGNI puts defense, data, and decisions at your fingertips—your farm, your rules, your future.',
  '"Farm the Land. Own the Brand." AGNI makes farmers founders—with profits rooted in every acre.',
  '"One Unit. Infinite Benefits." 25+ devices fused into a single, self-adapting core—nobody else gets close.',
  '"Profit Meets Planet." AGNI ends the compromise between growth and green. It\'s both.'
];

function App() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);
  const centralLineRef = useRef<HTMLDivElement>(null);
  const [typewriterText, setTypewriterText] = useState('');
  const [showCursor, setShowCursor] = useState(true);
  const [currentTaglineIndex, setCurrentTaglineIndex] = useState(0);

  useEffect(() => {
    let typewriterTimeout: NodeJS.Timeout;
    let pauseTimeout: NodeJS.Timeout;

    const startTypewriter = () => {
      let index = 0;
      const currentTagline = taglines[currentTaglineIndex];
      setTypewriterText('');

      const typeNextChar = () => {
        if (index < currentTagline.length) {
          setTypewriterText(currentTagline.slice(0, index + 1));
          index++;
          typewriterTimeout = setTimeout(typeNextChar, 50);
        } else {
          // Pause for 3 seconds before moving to next tagline
          pauseTimeout = setTimeout(() => {
            setCurrentTaglineIndex((prev) => (prev + 1) % taglines.length);
          }, 3000);
        }
      };

      typeNextChar();
    };

    startTypewriter();

    // Cursor blinking effect
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 500);

    return () => {
      clearTimeout(typewriterTimeout);
      clearTimeout(pauseTimeout);
      clearInterval(cursorInterval);
    };
  }, [currentTaglineIndex]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.target === titleRef.current) {
            if (entry.isIntersecting) {
              entry.target.classList.add('animate-fade-in-up');
              entry.target.classList.remove('animate-fade-out-down');
            } else {
              entry.target.classList.add('animate-fade-out-down');
              entry.target.classList.remove('animate-fade-in-up');
            }
          } else {
            const cardIndex = cardsRef.current.indexOf(entry.target as HTMLDivElement);
            if (cardIndex !== -1) {
              if (entry.isIntersecting) {
                // Quick and gentle entrance with custom stagger
                setTimeout(() => {
                  entry.target.classList.add('animate-card-enter');
                  entry.target.classList.remove('animate-card-exit');
                }, cardIndex * 50); // Reduced stagger for quicker sequence
              } else {
                // Quick and gentle exit
                setTimeout(() => {
                  entry.target.classList.add('animate-card-exit');
                  entry.target.classList.remove('animate-card-enter');
                }, (cardsRef.current.length - cardIndex - 1) * 30); // Even quicker exit stagger
              }
            }
          }
        });
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px',
      }
    );

    if (titleRef.current) {
      observer.observe(titleRef.current);
    }

    cardsRef.current.forEach((card) => {
      if (card) {
        observer.observe(card);
      }
    });

    // Central line scroll animation
    const handleScroll = () => {
      if (centralLineRef.current && sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        const scrollProgress = Math.max(0, Math.min(1, (window.innerHeight - rect.top) / (window.innerHeight + rect.height)));
        centralLineRef.current.style.setProperty('--scroll-progress', scrollProgress.toString());
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial call

    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>, cardRef: HTMLDivElement) => {
    const rect = cardRef.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    cardRef.style.setProperty('--mouse-x', `${x}px`);
    cardRef.style.setProperty('--mouse-y', `${y}px`);
  };

  return (
    <div className="min-h-screen bg-white">
      <section
        ref={sectionRef}
        className="relative py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
      >
        {/* Background Aurora Effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-[#82f3b8]/3 via-[#dbfdeb]/2 to-transparent blur-3xl animate-aurora-slow"></div>
        </div>

        {/* Central Line with Neon Effect */}
        <div 
          ref={centralLineRef}
          className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[#b9f9d6] to-transparent opacity-0 lg:opacity-100 central-line"
        ></div>

        {/* Section Title */}
        <div className="text-center mb-20">
          <h2
            ref={titleRef}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#004a56] mb-6 opacity-0 transform translate-y-8 transition-all duration-1000"
          >
            Core Powers of AGNI
          </h2>
          <div className="text-xl text-[#004a56]/70 max-w-4xl mx-auto min-h-[3rem] flex items-center justify-center font-poppins">
            <span className="typewriter-text">
              {typewriterText}
              <span className={`typewriter-cursor ${showCursor ? 'opacity-100' : 'opacity-0'}`}>|</span>
            </span>
          </div>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {agniFeatures.map((feature, index) => {
            const Icon = feature.icon;
            const isLeftCard = index % 2 === 0;
            
            return (
              <div
                key={index}
                ref={(el) => {
                  if (el) cardsRef.current[index] = el;
                }}
                className={`group relative bg-white rounded-2xl p-8 border border-gray-100 opacity-0 transform transition-all duration-700 hover:scale-[1.02] feature-card cursor-hover-effect ${
                  isLeftCard ? 'card-left' : 'card-right'
                }`}
                style={{
                  transform: 'translateY(40px) scale(0.96)',
                  opacity: 0
                }}
                onMouseMove={(e) => handleMouseMove(e, e.currentTarget)}
              >
                {/* Animated Border Gradient on Hover */}
                <div className="absolute inset-0 rounded-2xl pointer-events-none border-gradient-effect"></div>

                {/* Neon Edge Effect */}
                <div className={`absolute top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-[#b9f9d6] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 neon-edge ${
                  isLeftCard ? 'right-0' : 'left-0'
                }`}></div>

                {/* Reduced Hover Glow Effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-radial from-[#82f3b8]/10 via-[#dbfdeb]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
                
                {/* Reduced Inner Spotlight */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-radial from-[#dbfdeb]/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                {/* Card Border Glow */}
                <div className="absolute inset-0 rounded-2xl border border-[#82f3b8]/0 group-hover:border-[#82f3b8]/20 transition-all duration-500 group-hover:shadow-[0_0_20px_rgba(130,243,184,0.2)]"></div>

                {/* Card Content - Centered */}
                <div className="relative z-10 text-center">
                  <div className="mb-6 p-4 rounded-xl bg-gradient-to-br from-[#82f3b8]/10 to-[#dbfdeb]/10 group-hover:from-[#82f3b8]/15 group-hover:to-[#dbfdeb]/15 transition-all duration-500 w-fit mx-auto">
                    <Icon className="w-8 h-8 text-[#004a56] group-hover:text-[#004a56] transition-colors duration-300" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-[#004a56] mb-4 group-hover:text-[#004a56] transition-colors duration-300">
                    {feature.title}
                  </h3>
                  
                  <p className="text-[#004a56]/80 leading-relaxed group-hover:text-[#004a56]/90 transition-colors duration-300 font-poppins">
                    {feature.description}
                  </p>
                </div>

                {/* Elevated Shadow */}
                <div className="absolute inset-0 rounded-2xl shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-500 group-hover:shadow-xl"></div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}

export default App;