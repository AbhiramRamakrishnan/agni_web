/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      animation: {
        'aurora-slow': 'aurora 8s ease-in-out infinite',
        'fade-in-up': 'fadeInUp 1s ease-out forwards',
        'card-enter': 'cardEnter 0.8s ease-out forwards',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(circle, var(--tw-gradient-stops))',
      },
      colors: {
        'agni-primary': '#2e7377',
        'agni-glow': '#82f3b8',
        'agni-spotlight': '#dbfdeb',
      },
      boxShadow: {
        'glow': '0 0 30px rgba(130, 243, 184, 0.3)',
        'glow-intense': '0 0 50px rgba(130, 243, 184, 0.5)',
      },
    },
  },
  plugins: [],
};